#include <iostream.h>
#include <string.h>

using namespace std;

char* convert_to_char()