#include <iostream>
#include <string>
#include "bwt.h"
#include "mtf.h"
#include "hfm.h"

using namespace std;

string get_ascii() {
	string ascii;

	for(int i = 0; i < 128; i++) {
		ascii += char(i);
	}

	return ascii;
}

int main(int argc, char *argv[]) {
	char text[] = "SIX.MIXED.PIXIES.SIFT.SIXTY.PIXIE.DUST.BOXES$";
	string ascii = get_ascii();
	int k;
	int n = strlen(text);

	char* bwte1 = bwte(text, n, k);
	char* bwtd1 = bwtd(bwte1, n, k);
	char* mtfe1 = mtfe(bwte1, n, ascii);
	char* mtfd1 = mtfd(mtfe1, n, ascii);
	string hfme1 = hfme(mtfe1, n);
	cout << "bwte1 : " << bwte1 << endl;
	cout << "bwtd1 : " << bwtd1 << endl;
	cout << "mtfe1 : " << mtfe1 << endl;
	cout << "mtfd1 : " << mtfd1 << endl;
	cout << "hfme1 : " << hfme1 << endl;
	
	return 0;
}