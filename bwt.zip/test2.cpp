#include <iostream>
#include <string>

using namespace std;

int main() {
	char ch;

	cout << "ch" << ch << endl;

	return 0;
}