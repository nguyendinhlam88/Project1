using namespace std;

string hfme(char* arr, int n);
string hfmd(char* arr, int n);