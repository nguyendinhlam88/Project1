using namespace std;

char* mtfe(char* arr, int n, string ascii);
char* mtfd(char* arr, int n, string ascii);
