//header : bwt
char* bwte(char* arr, int n, int &k);
char* bwtd(char* arr, int n, int k);
